'''--------------------------- Init Script ---------------------------------'''
from owlpy.core import stamp

